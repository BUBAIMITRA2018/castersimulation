import numpy as np
b = np.longlong(999999999999999999)
print(b)